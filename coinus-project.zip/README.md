# coinus

coinus 저장소

## 환경 설치

프로젝트 환경 설치를 위해서 [Yarn](https://yarnpkg.com/lang/en/)이 필요합니다. 설치되어 있지 않은 경우 아래 명령어를 통해 설치해주세요.

```
npm install --global yarn
```

Yarn을 설치하였거나 이미 설치된 경우 아래 명령어를 통해 NPM 패키지를 설치할 수 있습니다.

```
yarn
```

패키지 설치가 완료되면 [Gulp](https://gulpjs.com/)를 통해 개발 환경을 시작할 수 있습니다. 아래와 같이 실행해주세요.

```
gulp
```